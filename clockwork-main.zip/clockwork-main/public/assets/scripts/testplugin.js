/*plugin name: Clockwork Test Plugin*/
alert("Hello world!")

var ready;